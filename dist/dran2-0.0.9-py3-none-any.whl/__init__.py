# Do not delete
logFile="logfile.txt"
__app__name = "dran"
__author__ = "Pfesesani van Zyl"
__package__ ="DRAN"
__DBNAME__='HART26DATA.db'

