logfile="logfile.txt"
__app__name = "dran"
__version__ = "1.0.0"
__DBNAME__='HART26DATA.db'