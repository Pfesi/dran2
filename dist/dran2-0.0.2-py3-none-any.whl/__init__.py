# Do not delete
logFile="logfile.txt"
__app__name = "dran"
__version__ = "0.0.1"
__author__ = "Pfesesani van Zyl"
__package__ ="DRAN"
__DBNAME__='HART26DATA.db'