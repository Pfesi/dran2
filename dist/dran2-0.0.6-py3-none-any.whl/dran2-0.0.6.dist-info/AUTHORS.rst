
Authors
=======
* Pfesesani van Zyl 
- Github: https://github.com/Pfesi/dran/
- LinkedIn: https://www.linkedin.com/in/pfesi-van-zyl-ph-d-1b430a41/
- Google page:  
- Google scholar profile: https://scholar.google.com/citations?user=Cco6gzsAAAAJ&hl=en&oi=ao
- NASA ADS: https://ui.adsabs.harvard.edu/search/fq=%7B!type%3Daqp%20v%3D%24fq_database%7D&fq=%7B!type%3Daqp%20v%3D%24fq_author%7D&fq_author=(author_facet_hier%3A%221%2Fvan%20Zyl%2C%20P%2Fvan%20Zyl%2C%20P%22%20OR%20author_facet_hier%3A%221%2Fvan%20Zyl%2C%20P%2Fvan%20Zyl%2C%20Pfesesani%22%20OR%20author_facet_hier%3A%221%2Fvan%20Zyl%2C%20P%2Fvan%20Zyl%2C%20P%20%20V%22%20OR%20author_facet_hier%3A%221%2Fvan%20Zyl%2C%20P%2Fvan%20Zyl%2C%20Pfesesani%20V%22)&fq_database=(database%3Aastronomy%20OR%20database%3Aphysics)&q=Pfesesani%20van%20zyl&sort=date%20desc%2C%20bibcode%20desc&p_=0
- ATels: 
- ORCID: https://orcid.org/0000-0002-7510-6366